/*
  ============================================================================
   ESP32 DevKit C - Generador de Portadora Continua (CW / Constant TX Mode)
   Módulos: 2x nRF24L01+ HP (TRW24HP)  -  Arduino Framework (setup/loop)
  ============================================================================

   Qué hace este código:
   - Pone ambos módulos en modo de PORTADORA CONTINUA (CONT_WAVE del chip
     nRF24L01+). No se transmiten paquetes, solo una señal de RF pura, ideal
     para verla en un analizador de espectro.
   - Permite elegir entre CANAL FIJO o BARRIDO SECUENCIAL de canal (sweep).
   - El barrido se controla con un TIMER por hardware (ISR): el ISR solo
     levanta una bandera (flag); el cambio real de canal (que usa SPI) se
     hace en loop(), como corresponde en ESP32 (no se debe usar SPI dentro
     de una ISR).
   - TODOS los pines y velocidades son editables en la sección de macros.

   Librería necesaria (Arduino Library Manager):
     "RF24" de TMRh20  ->  https://github.com/nRF24/RF24
     (Debe incluir startConstCarrier() / stopConstCarrier(); son parte de la
      librería desde hace varios años, si tu versión es muy vieja actualizala)

   Notas de hardware:
   - Los dos módulos comparten el mismo bus SPI (SCK, MISO, MOSI) pero cada
     uno tiene su propio CE y su propio CSN.
   - CE1 = GPIO4 (D4) y CE2 = GPIO32 (D32), tal como pediste. Los CSN y el
     bus SPI quedaron en pines típicos del ESP32 DevKit (VSPI), pero podés
     cambiar cualquiera de ellos abajo sin tocar el resto del código.
   - No se usa WiFi ni Bluetooth internos del ESP32, solo SPI + GPIO.

   Nota sobre el core de Arduino-ESP32:
   - Este código usa la API de timer "clásica" (timerBegin con prescaler,
     timerAttachInterrupt con función y edge). Corresponde al core
     Arduino-ESP32 v2.x. Si tenés instalado el core v3.x, la API de timer
     cambió (timerBegin ya no lleva prescaler ni timerAlarmWrite se usa
     igual); en ese caso avisame y te paso la versión adaptada.
  ============================================================================
*/

#include <Arduino.h>
#include <SPI.h>
#include <RF24.h>

// ============================================================
// 1) CONFIGURACIÓN DE PINES (EDITABLE)
// ============================================================

// --- Módulo 1 ---
#define CE1_PIN     4     // Enable 1  (pedido: D4)
#define CSN1_PIN    5     // Chip Select 1

// --- Módulo 2 ---
#define CE2_PIN     32    // Enable 2  (pedido: D32)
#define CSN2_PIN    33    // Chip Select 2

// --- Bus SPI compartido (VSPI por defecto en ESP32 DevKit C) ---
#define SCK_PIN     18
#define MISO_PIN    19
#define MOSI_PIN    23

// ============================================================
// 2) CONFIGURACIÓN DE RF (EDITABLE)
// ============================================================
#define PA_LEVEL      RF24_PA_MAX   // Potencia interna del chip nRF24
                                     // (no es la potencia del PA externo del
                                     //  TRW24HP, eso lo maneja la fuente externa)
#define DATA_RATE     RF24_1MBPS    // RF24_250KBPS / RF24_1MBPS / RF24_2MBPS

// ============================================================
// 3) MODO DE OPERACIÓN (EDITABLE)
// ============================================================
#define MODE_FIXED_CHANNEL   0
#define MODE_SWEEP           1

#define OPERATION_MODE       MODE_SWEEP   // <-- cambiar a MODE_FIXED_CHANNEL
                                           //     para transmitir en un solo canal

#define FIXED_CHANNEL         40   // Solo se usa si OPERATION_MODE = MODE_FIXED_CHANNEL
                                    // (rango válido nRF24: 0 a 125)

// ============================================================
// 4) CONFIGURACIÓN DEL BARRIDO / SWEEP (EDITABLE)
// ============================================================
#define SWEEP_CH_START        0     // Canal inicial (0-125)
#define SWEEP_CH_END           125  // Canal final   (0-125)
#define SWEEP_CH_STEP           1   // Incremento entre canales

// Velocidad del barrido: tiempo entre cada cambio de canal, en microsegundos.
// Subí este valor para verlo "lento" y analizar la salida con más detalle.
//   500000UL   = 0.5 s por canal (rápido-medio)
//   2000000UL  = 2 s por canal   (lento, ideal para observar en el analizador)
#define SWEEP_INTERVAL_US   500000UL   // <-- EDITAR ACÁ LA VELOCIDAD

// ============================================================
// OBJETOS RF24
// ============================================================
RF24 radio1(CE1_PIN, CSN1_PIN);
RF24 radio2(CE2_PIN, CSN2_PIN);

// ============================================================
// VARIABLES DE TIMER / ISR
// ============================================================
hw_timer_t *sweepTimer = NULL;
portMUX_TYPE timerMux = portMUX_INITIALIZE_LOCK();

volatile bool    channelChangeFlag = false;
volatile uint8_t currentChannel    = SWEEP_CH_START;

// ============================================================
// PROTOTIPOS
// ============================================================
void IRAM_ATTR onSweepTimer();
void configurarModuloCW(RF24 &radio);
void iniciarPortadora(RF24 &radio, uint8_t channel);
void actualizarCanalAmbosModulos(uint8_t channel);

// ============================================================
// ISR DEL TIMER
// Solo marca una bandera. NUNCA se hacen llamadas SPI/RF24 acá.
// ============================================================
void IRAM_ATTR onSweepTimer() {
  portENTER_CRITICAL_ISR(&timerMux);
  channelChangeFlag = true;
  portEXIT_CRITICAL_ISR(&timerMux);
}

// ============================================================
// Configura un módulo para modo de portadora continua (CW)
// ============================================================
void configurarModuloCW(RF24 &radio) {
  radio.begin();
  radio.setAutoAck(false);
  radio.stopListening();
  radio.setPALevel(PA_LEVEL);
  radio.setDataRate(DATA_RATE);
  radio.setRetries(0, 0);
}

// ============================================================
// Inicia la portadora continua (CONT_WAVE) en un canal específico
// ============================================================
void iniciarPortadora(RF24 &radio, uint8_t channel) {
  radio.stopConstCarrier();       // aseguramos estado limpio antes de arrancar
  radio.setChannel(channel);
  radio.startConstCarrier(PA_LEVEL, channel);
}

// ============================================================
// Cambia el canal de ambos módulos al mismo tiempo (usado en el sweep)
// ============================================================
void actualizarCanalAmbosModulos(uint8_t channel) {
  radio1.stopConstCarrier();
  radio2.stopConstCarrier();

  radio1.setChannel(channel);
  radio2.setChannel(channel);

  radio1.startConstCarrier(PA_LEVEL, channel);
  radio2.startConstCarrier(PA_LEVEL, channel);
}

// ============================================================
// SETUP
// ============================================================
void setup() {
  Serial.begin(115200);
  delay(200);

  Serial.println("=== Iniciando modo Constant TX (CW) - TRW24HP x2 ===");

  // Inicializa el bus SPI con los pines definidos arriba
  SPI.begin(SCK_PIN, MISO_PIN, MOSI_PIN);

  configurarModuloCW(radio1);
  configurarModuloCW(radio2);

#if OPERATION_MODE == MODE_FIXED_CHANNEL
  Serial.print("Modo: CANAL FIJO -> canal ");
  Serial.println(FIXED_CHANNEL);

  iniciarPortadora(radio1, FIXED_CHANNEL);
  iniciarPortadora(radio2, FIXED_CHANNEL);

#elif OPERATION_MODE == MODE_SWEEP
  Serial.println("Modo: BARRIDO SECUENCIAL DE CANAL (SWEEP)");

  currentChannel = SWEEP_CH_START;
  actualizarCanalAmbosModulos(currentChannel);

  // --- Configuración del timer hardware para el barrido ---
  // timerBegin(numero_timer, prescaler, cuenta_ascendente)
  // Con prescaler 80 sobre un clock de 80MHz, cada tick del timer = 1 us
  sweepTimer = timerBegin(0, 80, true);
  timerAttachInterrupt(sweepTimer, &onSweepTimer, true);
  timerAlarmWrite(sweepTimer, SWEEP_INTERVAL_US, true); // recarga automática
  timerAlarmEnable(sweepTimer);
#endif

  Serial.println("Portadora activa.");
}

// ============================================================
// LOOP PRINCIPAL
// ============================================================
void loop() {
#if OPERATION_MODE == MODE_SWEEP
  if (channelChangeFlag) {
    portENTER_CRITICAL(&timerMux);
    channelChangeFlag = false;
    portEXIT_CRITICAL(&timerMux);

    currentChannel += SWEEP_CH_STEP;
    if (currentChannel > SWEEP_CH_END) {
      currentChannel = SWEEP_CH_START;
    }

    actualizarCanalAmbosModulos(currentChannel);

    Serial.print("Canal actual: ");
    Serial.println(currentChannel);
  }
#endif

  // En modo canal fijo no hace falta hacer nada más en el loop:
  // la portadora queda transmitiendo continuamente.
}
