#ifndef TIMER_ESP32_H
#define TIMER_ESP32_H

#ifdef __cplusplus
extern "C" {
#endif

#include <Arduino.h>

// Inicializa el timer hardware (tick de 1ms) y arranca la interrupcion
void init_timer0(void);

/*
devuelve el tiempo en milisegundos (32bit) desde que arranco el timer0
*/
uint32_t get_time(void);
void set_time(uint32_t time);

uint8_t get_valor(void);
void set_valor(uint8_t new_valor);

#ifdef __cplusplus
}
#endif

#endif
