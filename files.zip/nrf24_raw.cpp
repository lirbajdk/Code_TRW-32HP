#include "nrf24_raw.h"
#include <SPI.h>
#include "config.h"

// ---------------- Registros y comandos del nRF24L01(+)/TRW24HP -----------
#define NRF_CMD_R_REGISTER     0x00
#define NRF_CMD_W_REGISTER     0x20
#define NRF_CMD_FLUSH_TX       0xE1
#define NRF_CMD_FLUSH_RX       0xE2
#define NRF_CMD_NOP            0xFF

#define REG_CONFIG      0x00
#define REG_EN_AA       0x01
#define REG_RF_CH       0x05
#define REG_RF_SETUP    0x06
#define REG_STATUS      0x07

// Bits del registro CONFIG
#define CONFIG_PWR_UP   (1 << 1)
#define CONFIG_PRIM_RX  (1 << 0)

// Bits del registro RF_SETUP
#define RF_SETUP_CONT_WAVE  (1 << 7)   // portadora continua sin modular
#define RF_SETUP_PLL_LOCK   (1 << 4)   // fuerza el lock de la PLL (necesario junto a CONT_WAVE)

static SPISettings nrfSpiSettings(4000000, MSBFIRST, SPI_MODE0);

static inline void csn_low(uint8_t csn_pin)  { digitalWrite(csn_pin, LOW); }
static inline void csn_high(uint8_t csn_pin) { digitalWrite(csn_pin, HIGH); }

static void nrf24_command(uint8_t csn_pin, uint8_t cmd) {
    SPI.beginTransaction(nrfSpiSettings);
    csn_low(csn_pin);
    SPI.transfer(cmd);
    csn_high(csn_pin);
    SPI.endTransaction();
}

static void nrf24_write_reg(uint8_t csn_pin, uint8_t reg, uint8_t value) {
    SPI.beginTransaction(nrfSpiSettings);
    csn_low(csn_pin);
    SPI.transfer(NRF_CMD_W_REGISTER | (reg & 0x1F));
    SPI.transfer(value);
    csn_high(csn_pin);
    SPI.endTransaction();
}

void nrf24_bus_init(void) {
    pinMode(PIN_CSN_1, OUTPUT);
    pinMode(PIN_CSN_2, OUTPUT);
    pinMode(PIN_CE_1, OUTPUT);
    pinMode(PIN_CE_2, OUTPUT);

    digitalWrite(PIN_CSN_1, HIGH);
    digitalWrite(PIN_CSN_2, HIGH);
    digitalWrite(PIN_CE_1, LOW);
    digitalWrite(PIN_CE_2, LOW);

    // SPI.begin(sck, miso, mosi, ss) -> ss en -1 porque el CS lo
    // manejamos a mano con digitalWrite (hay dos modulos, no uno solo)
    SPI.begin(PIN_SCK, PIN_MISO, PIN_MOSI, -1);
}

void nrf24_start_constant_carrier(uint8_t ce_pin, uint8_t csn_pin,
                                   uint8_t channel, uint8_t power_level) {
    digitalWrite(ce_pin, LOW);

    // Encendemos el chip y lo dejamos en modo TX (PRIM_RX = 0)
    nrf24_write_reg(csn_pin, REG_CONFIG, CONFIG_PWR_UP);
    delay(2); // tiempo de arranque tras PWR_UP (datasheet: ~1.5ms)

    // Auto-ACK no aplica en modo portadora continua
    nrf24_write_reg(csn_pin, REG_EN_AA, 0x00);

    // Canal de RF
    nrf24_write_reg(csn_pin, REG_RF_CH, channel & 0x7F);

    // Potencia + bits CONT_WAVE y PLL_LOCK -> portadora continua sin modular
    uint8_t rf_setup = ((power_level & 0x03) << 1) | RF_SETUP_CONT_WAVE | RF_SETUP_PLL_LOCK;
    nrf24_write_reg(csn_pin, REG_RF_SETUP, rf_setup);

    // Vaciamos el FIFO de TX por las dudas (no se usa en este modo, pero
    // deja el chip en un estado limpio)
    nrf24_command(csn_pin, NRF_CMD_FLUSH_TX);

    // Subimos CE: con CONT_WAVE + PLL_LOCK ya en 1, esto activa la
    // portadora continua en el canal configurado
    digitalWrite(ce_pin, HIGH);
}

void nrf24_set_channel(uint8_t csn_pin, uint8_t channel) {
    nrf24_write_reg(csn_pin, REG_RF_CH, channel & 0x7F);
}
