#include <Arduino.h>
#include "config.h"
#include "timer_esp32.h"
#include "nrf24_raw.h"

static uint8_t  canal_actual  = SWEEP_START_CH;
static uint32_t ultimo_cambio = 0;

// Recorre los canales de forma secuencial usando el timer (ISR de 1ms)
// como base de tiempo, en vez de delay().
static void hacer_barrido(void) {
    uint32_t ahora = get_time();

    if ((ahora - ultimo_cambio) >= SWEEP_STEP_MS) {
        ultimo_cambio = ahora;

        nrf24_set_channel(PIN_CSN_1, canal_actual);
        nrf24_set_channel(PIN_CSN_2, canal_actual);
        set_valor(canal_actual); // guarda el canal actual en la variable "valor"

        Serial.print("Canal actual: ");
        Serial.println(canal_actual);

        canal_actual++;
        if (canal_actual > SWEEP_END_CH) {
            canal_actual = SWEEP_START_CH;
        }
    }
}

void setup(void) {
    Serial.begin(115200);
    delay(200);

    nrf24_bus_init();
    init_timer0();

#if MODE_SWEEP
    canal_actual = SWEEP_START_CH;
    nrf24_start_constant_carrier(PIN_CE_1, PIN_CSN_1, canal_actual, RF_POWER_LEVEL);
    nrf24_start_constant_carrier(PIN_CE_2, PIN_CSN_2, canal_actual, RF_POWER_LEVEL);
    Serial.println("Modo: BARRIDO SECUENCIAL");
#else
    nrf24_start_constant_carrier(PIN_CE_1, PIN_CSN_1, FIXED_CHANNEL, RF_POWER_LEVEL);
    nrf24_start_constant_carrier(PIN_CE_2, PIN_CSN_2, FIXED_CHANNEL, RF_POWER_LEVEL);
    Serial.print("Modo: PORTADORA FIJA - Canal ");
    Serial.println(FIXED_CHANNEL);
#endif
}

void loop(void) {
#if MODE_SWEEP
    hacer_barrido();
#endif
    // En modo portadora fija no hace falta nada en el loop: una vez
    // configurado el registro RF_SETUP y con CE en alto, el chip queda
    // transmitiendo la portadora solo, sin intervencion del micro.
}
