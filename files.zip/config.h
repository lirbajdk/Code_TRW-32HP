#ifndef CONFIG_H
#define CONFIG_H

// ==================================================================
//  CONFIGURACION DE PINES - EDITAR ACA SEGUN TU CABLEADO
// ==================================================================

// --- Modulo TRW24HP #1 ---
#define PIN_CE_1    4      // Chip Enable modulo 1 (habilita TX)
#define PIN_CSN_1   5      // Chip Select (SPI CS) modulo 1

// --- Modulo TRW24HP #2 ---
#define PIN_CE_2    32     // Chip Enable modulo 2
#define PIN_CSN_2   33     // Chip Select (SPI CS) modulo 2

// --- Bus SPI compartido por ambos modulos (bus VSPI tipico del ESP32 DevKit) ---
#define PIN_SCK     18
#define PIN_MISO    19
#define PIN_MOSI    23

// ==================================================================
//  CONFIGURACION DE RF
// ==================================================================

// Potencia de salida (bits RF_PWR del registro RF_SETUP)
//  0 = -18dBm | 1 = -12dBm | 2 = -6dBm | 3 = 0dBm
// (esto solo afecta al PA interno del chip; como aclaraste que el
//  modulo tiene alimentacion/PA externo, dejalo en 3 salvo que quieras
//  limitar la salida del chip en si)
#define RF_POWER_LEVEL   3

// ==================================================================
//  MODO DE OPERACION
// ==================================================================

// 1 = barrido secuencial de canales (frequency sweep)
// 0 = portadora continua fija en un solo canal
#define MODE_SWEEP        1

// Canal fijo usado cuando MODE_SWEEP == 0  (rango valido 0-125)
#define FIXED_CHANNEL     40

// Rango de barrido cuando MODE_SWEEP == 1 (0-125)
#define SWEEP_START_CH    0
#define SWEEP_END_CH      125

// Velocidad del barrido: tiempo (ms) que se mantiene cada canal antes
// de saltar al siguiente. Subilo para verlo mas lento en el analizador.
#define SWEEP_STEP_MS     500

#endif
