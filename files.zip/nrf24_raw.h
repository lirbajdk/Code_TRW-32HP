#ifndef NRF24_RAW_H
#define NRF24_RAW_H

#include <Arduino.h>

// Inicializa pines y bus SPI compartido por los dos modulos
void nrf24_bus_init(void);

// Configura un modulo y lo deja transmitiendo una portadora continua
// (sin modular) en el canal indicado. ce_pin/csn_pin son los pines de
// control de ESE modulo en particular.
void nrf24_start_constant_carrier(uint8_t ce_pin, uint8_t csn_pin,
                                   uint8_t channel, uint8_t power_level);

// Cambia el canal de RF de un modulo que ya esta transmitiendo la
// portadora (usado por el barrido). No hace falta bajar el CE para
// cambiar de canal, el chip lo actualiza al vuelo.
void nrf24_set_channel(uint8_t csn_pin, uint8_t channel);

#endif
