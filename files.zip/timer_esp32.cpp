#include "timer_esp32.h"

/* ------------------------------------------------------------------
 * NOTA:
 * Tu libreria original usaba ISR(TIMER0_COMPA_vect), que es el vector
 * de interrupcion del Timer0 de un AVR (Arduino UNO/Nano). El ESP32
 * no tiene esos registros ni ese vector de interrupcion, asi que no
 * compila tal cual en el ESP32.
 *
 * Aca esta reescrita con el driver de timers hardware del core
 * arduino-esp32 (hw_timer_t), manteniendo las mismas funciones
 * (get_time / set_time / get_valor / set_valor) para que el resto de
 * tu logica no tenga que cambiar.
 * ------------------------------------------------------------------ */

static hw_timer_t *timer0 = NULL;
static portMUX_TYPE timerMux = portMUX_INITIALIZER_UNLOCKED;

static volatile uint32_t tiempo = 0;
static volatile uint8_t  valor  = 0;

void IRAM_ATTR onTimer0ISR(void) {
    portENTER_CRITICAL_ISR(&timerMux);
    tiempo++;
    portEXIT_CRITICAL_ISR(&timerMux);
}

void init_timer0(void) {
    // API del core arduino-esp32 2.x:
    // timerBegin(numero_timer, prescaler, cuenta_ascendente)
    // Clock base del ESP32 = 80MHz -> prescaler 80 => 1 tick = 1us
    timer0 = timerBegin(0, 80, true);
    timerAttachInterrupt(timer0, &onTimer0ISR, true);
    timerAlarmWrite(timer0, 1000, true);   // 1000us = 1ms, auto-reload
    timerAlarmEnable(timer0);

    /* Si tu core arduino-esp32 instalado es 3.x, la API cambio de firma.
     * En ese caso comenta las 4 lineas de arriba y usa estas:
     *
     *   timer0 = timerBegin(1000000);               // frecuencia del timer en Hz
     *   timerAttachInterrupt(timer0, &onTimer0ISR);  // sin tercer parametro
     *   timerAlarm(timer0, 1000, true, 0);           // 1000 ticks = 1ms
     */
}

uint32_t get_time(void) {
    portENTER_CRITICAL(&timerMux);
    uint32_t t = tiempo;
    portEXIT_CRITICAL(&timerMux);
    return t;
}

void set_time(uint32_t time) {
    portENTER_CRITICAL(&timerMux);
    tiempo = time;
    portEXIT_CRITICAL(&timerMux);
}

uint8_t get_valor(void) {
    return valor;
}

void set_valor(uint8_t new_valor) {
    valor = new_valor;
}
